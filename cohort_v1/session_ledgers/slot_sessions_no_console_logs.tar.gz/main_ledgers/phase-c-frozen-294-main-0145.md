# Trajectory Proposal Generator — Run Output

Engine: TGAA_TPG_v1.3.1
Axiom: Valid(τ) = I(τ) ∧ Terminal(τ) ∧ Efficiency(τ) ∧ Stability(τ)
Tasks: 1 (PASS=1, REPAIR=0, DEGRADED=0, FAIL=0)
Combination leakage: False
Compression invalid: False
Transfer failure: False
Transfer evidence unproven: False

Level tags (L1/L2/L3) are provenance-only stratification metadata (task_provenance / batch stats). They are NOT part of any training token sequence (steps[*].state / decision) — true supervision signal is the τ = (s₀,C₀,a₁,s₁,…,sₙ) state-transition text itself.

Dataset preview: 1 tasks rendered.

## TASK_001 — `TECH-03.TECH-04.TECH-09.TECH-12` (2 trajectories)
- task_input: `finance:slot0#TECH-03.TECH-04.TECH-09.TECH-12` — domain=finance level=L2

### Successful_Path — 7 step(s)
- Step 1: `CHECK_INITIAL_STATE` — Initialize the dependency ledger.
- Step 2: `APPLY_LOCAL_UPDATE` — Apply the declared versioned update while preserving the dependency ledger.
- Step 3: `RESOLVE_legal_authority_basis` — Resolved through the deterministic dependency order and established supporting record.
- Step 4: `RESOLVE_material_facts_established` — Resolved through the deterministic dependency order and established supporting record.
- Step 5: `RESOLVE_procedural_requirements_met` — Resolved through the deterministic dependency order and established supporting record.
- Step 6: `RESOLVE_legal_conclusion_supported` — Resolved through the deterministic dependency order and established supporting record.
- Step terminal: `TERMINAL_DERIVED` — All constraints are resolved.

### Counterfactual_Near_Miss — 7 step(s)
- Step 1: `CHECK_INITIAL_STATE` — Initialize the dependency ledger.
- Step 2: `APPLY_LOCAL_UPDATE` — Apply the declared versioned update while preserving the dependency ledger.
- Step 3: `RESOLVE_legal_authority_basis` — Resolved through the deterministic dependency order and established supporting record.
- Step 4: `RESOLVE_material_facts_established` — Resolved through the deterministic dependency order and established supporting record.
- Step 5: `GLOBAL_RESET` — Variation-specific shortcut bypassed the required safeguard for procedural_requirements_met.
- Step 6: `RESOLVE_legal_conclusion_supported` — Resolved through the deterministic dependency order and established supporting record.
- Step terminal: `INVALID_TERMINAL` — procedural_requirements_met remains unresolved.