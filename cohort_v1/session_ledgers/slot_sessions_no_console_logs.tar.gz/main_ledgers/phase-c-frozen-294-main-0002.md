# Trajectory Proposal Generator — Run Output

Engine: TGAA_TPG_v1.3.1
Axiom: Valid(τ) = I(τ) ∧ Terminal(τ) ∧ Efficiency(τ) ∧ Stability(τ)
Tasks: 1 (PASS=1, REPAIR=0, DEGRADED=0, FAIL=0)
Combination leakage: False
Compression invalid: False
Transfer failure: False
Transfer evidence unproven: False

Level tags (L1/L2/L3) are provenance-only stratification metadata (task_provenance / batch stats). They are NOT part of any training token sequence (steps[*].state / decision) — true supervision signal is the τ = (s₀,C₀,a₁,s₁,…,sₙ) state-transition text itself.

Dataset preview: 1 tasks rendered.

## TASK_001 — `TECH-04.TECH-08` (2 trajectories)
- task_input: `legal:slot0#TECH-04.TECH-08` — domain=legal level=L2

### Successful_Path — 5 step(s)
- Step 1: `CHECK_INITIAL_STATE` — Initialize the dependency ledger.
- Step 2: `RESOLVE_governing_authority` — TECH-04 requires resolving the recorded governing authority before dependent jurisdictional analysis.
- Step 3: `RESOLVE_jurisdictional_scope` — The applicable jurisdiction and procedural posture constrain analysis after governing authority is established.
- Step 4: `RESOLVE_evidentiary_record` — The evidentiary record supports conclusions only after authority and jurisdictional scope have been resolved.
- Step terminal: `TERMINAL_DERIVED` — All constraints are resolved.

### Counterfactual_Near_Miss — 5 step(s)
- Step 1: `CHECK_INITIAL_STATE` — Initialize the dependency ledger.
- Step 2: `RESOLVE_governing_authority` — TECH-04 requires resolving the recorded governing authority before dependent jurisdictional analysis.
- Step 3: `ACCEPT_FALSE_AUTHORITY` — Variation-specific shortcut bypassed the required safeguard for jurisdictional_scope.
- Step 4: `RESOLVE_evidentiary_record` — The evidentiary record supports conclusions only after authority and jurisdictional scope have been resolved.
- Step terminal: `INVALID_TERMINAL` — jurisdictional_scope remains unresolved.