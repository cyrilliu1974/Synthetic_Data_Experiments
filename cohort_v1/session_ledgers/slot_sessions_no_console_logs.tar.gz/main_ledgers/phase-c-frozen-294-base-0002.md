# Trajectory Proposal Generator — Run Output

Engine: TGAA_TPG_v1.3.1
Axiom: Valid(τ) = I(τ) ∧ Terminal(τ) ∧ Efficiency(τ) ∧ Stability(τ)
Tasks: 1 (PASS=0, REPAIR=0, DEGRADED=1, FAIL=0)
Combination leakage: False
Compression invalid: False
Transfer failure: False
Transfer evidence unproven: False

Level tags (L1/L2/L3) are provenance-only stratification metadata (task_provenance / batch stats). They are NOT part of any training token sequence (steps[*].state / decision) — true supervision signal is the τ = (s₀,C₀,a₁,s₁,…,sₙ) state-transition text itself.

Dataset preview: 1 tasks rendered.

## TASK_001 — `TECH-04.TECH-08` (2 trajectories)
- task_input: `legal:slot0#TECH-04.TECH-08` — domain=legal level=L2

### Successful_Path — 6 step(s)
- Step 1: `CHECK_INITIAL_STATE` — Initialize the dependency ledger.
- Step 2: `RESOLVE_legal_authority_basis` — Established the controlling authority basis before resolving dependent constraints.
- Step 3: `RESOLVE_material_facts_established` — Established material facts under the controlling authority basis.
- Step 4: `RESOLVE_procedural_requirements_met` — Confirmed procedural requirements under the authority basis.
- Step 5: `RESOLVE_legal_conclusion_supported` — Applied the supported conclusion after prerequisites were resolved.
- Step terminal: `TERMINAL_DERIVED` — All constraints are resolved.

### Counterfactual_Near_Miss — 6 step(s)
- Step 1: `CHECK_INITIAL_STATE` — Initialize the dependency ledger.
- Step 2: `RESOLVE_legal_authority_basis` — Established the controlling authority basis before resolving dependent constraints.
- Step 3: `RESOLVE_material_facts_established` — Established material facts under the controlling authority basis.
- Step 4: `ACCEPT_FALSE_AUTHORITY` — Variation-specific shortcut bypassed the required safeguard for procedural_requirements_met.
- Step 5: `RESOLVE_legal_conclusion_supported` — Applied the supported conclusion after prerequisites were resolved.
- Step terminal: `INVALID_TERMINAL` — procedural_requirements_met remains unresolved.